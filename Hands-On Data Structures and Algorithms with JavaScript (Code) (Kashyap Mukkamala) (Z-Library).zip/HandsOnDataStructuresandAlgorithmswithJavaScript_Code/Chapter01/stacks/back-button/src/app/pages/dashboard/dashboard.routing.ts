import { DashboardComponent } from './dashboard.component';

export const DashboardRoutes = [
    { path: 'dashboard', component: DashboardComponent },
];

export const DashboardComponents = [
    DashboardComponent
];